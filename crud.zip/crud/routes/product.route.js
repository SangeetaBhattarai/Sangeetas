const express = require('express');
const router = express.Router();

const product_controller = require('../controllers/product.controller');



router.post('/create', product_controller.product_create);
router.get('/:id', product_controller.product_details);
 router.put('/:id/update', product_controller.product_update);
 router.delete('/:id/delete', product_controller.product_delete);

// router.post('/create', (req, res, next) => {
//     console.log("fsdsdfssfsdsd");
//     return product_controller.product_create(req, res, next)
// });  


router.get('/test', (req, res, next) => {
    console.log("fsdsdfssfsdsd");
    return product_controller.test(req, res, next)
});   
module.exports = router;