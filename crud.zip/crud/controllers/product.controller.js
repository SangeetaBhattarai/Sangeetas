const Product = require('../models/product.model');

exports.product_create = function (req, res,next) {
    
    let product = new Product(
        {
            name: req.body.name,
            price: req.body.price
        }
    );

    product.save(function (err) {
        if (err) {
            return next(err);
            // return res.status(400).send("error 1");
        }
        res.send('Product Created successfully')
    })
};



// module.exports.product_details = function (req, res, next) {
//    Product.findById(req.params.id, function (err, product) {
//         if (err) {
//             // return next(err);
//             return res.status(400).send("error 2");
//         }
//         res.send(product);
//     })
// };


 module.exports.product_update = function (req, res, next) {
     Product.findByIdAndUpdate(req.params.id, {$set: req.body}, function (err, product) {
        if (err) {
             // return next(err);
             return res.status(400).send("error 3");
         }
        res.send('Product udpated.');
     });
 };



 module.exports.product_delete = function (req, res,next) {
     Product.findByIdAndRemove(req.params.id, function (err) {
         if (err) return next(err);
         res.send('Deleted successfully!');
     })
 };


// function product_create(req, res) {
    
//     let product = new Product(
//         {
//             name: req.body.name,
//            price: req.body.price
//        }
//     );

//    product.save(function (err) {
//          if (err) {
//             // return next(err);
//             console.log(err);
//             return res.status(400).send("error 1");
//        }
//          res.send('Product Created successfully')
//      })
//  }


module.exports.product_details = function (req, res, next) {
        Product.findById(req.params.id, function (err, product) {
             if (err) {
                 // return next(err);
                 return res.status(400).send("error 2");
             }
             res.send(product);
         })
     };
    





function test(req, res) {
    return res.send('Greetings from the Test controller!');;
}

 //module.exports = {
    // test
   // product_create
      // product_details
 //};